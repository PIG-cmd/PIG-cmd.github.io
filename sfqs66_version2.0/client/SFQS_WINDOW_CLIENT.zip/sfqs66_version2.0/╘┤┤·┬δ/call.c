#include <stdlib.h>
int main(void)
{
	system("start sfqs66.exe & start /b download.exe");
	return 0;
}
